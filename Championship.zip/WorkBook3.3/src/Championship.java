
public class Championship {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		//See Learn the Part for the complete instructions (link in resources folder of Udemy video).  

        int gryffindor = 400;    //gryffindor points
        int ravenclaw = 200;    //ravenclaw points
        int margin = (gryffindor - ravenclaw);
        // int margin = amount of points by which gryffindor scored over ravenclaw;
		
		if (margin >= 300) {
			System.out.println("gryffindor wins the championship!");
		}
		else if (margin >= 0) {
			System.out.println("gryffindor comes in second");
		}
		else if (margin >= -100) {
			System.out.println(" gryffindor comes in third");
		}
		else  {
			System.out.println("gryffindor comes in 4th :(");
		}
		
	}

}
